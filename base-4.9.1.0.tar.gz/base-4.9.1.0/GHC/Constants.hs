{-# LANGUAGE Trustworthy #-}
{-# LANGUAGE NoImplicitPrelude #-}

module GHC.Constants where

-- TODO: This used to include HaskellConstants.hs, but that has now gone.
-- We probably want to include the constants in platformConstants somehow
-- instead.

import GHC.Base () -- dummy dependency
